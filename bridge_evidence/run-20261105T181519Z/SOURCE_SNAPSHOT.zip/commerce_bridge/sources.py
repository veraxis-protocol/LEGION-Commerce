import hashlib
import json
import subprocess
from pathlib import Path
from commerce_adapter.contracts import require

PINS={"LEGION":"d083c44af2526e38068e0220891cd0bb5fce52af",
      "ztl-swarm":"7d2a8265926aecab9a838b09059bd106941b5c18",
      "ZTL":"e1141c6893af6cf49f363620432ca6aaa0b06301"}
FILES={"LEGION":["tests/legion_struct/struct_controller.py","tests/legion_struct/world_engine.py","tests/legion_overlay/ztl_service.py"],
       "ztl-swarm":["ztlswarm/ztlrule.py","lean/ZSwarm.lean","lean/VerdictMain.lean","lean/lean-toolchain","lean/lakefile.toml"],
       "ZTL":["lean/ZLegion.lean","lean/ZRuntimeGate.lean","lean/lean-toolchain","lean/lakefile.toml"]}


class Sources:
    def __init__(self,root):
        self.root=Path(root).resolve()
        self.binary=self.root/"ztl-swarm/lean/.lake/build/bin/zverdict.exe"

    def verify(self):
        manifest={}
        for name,pin in PINS.items():
            repo=self.root/name
            def git(*args):
                return subprocess.run(["git","-C",str(repo),*args],capture_output=True,check=True,timeout=20).stdout
            require(git("rev-parse","HEAD").decode().strip()==pin,"SOURCE_COMMIT_MISMATCH")
            require(not git("status","--porcelain","--untracked-files=no").strip(),"SOURCE_TRACKED_CHANGES")
            hashes={}
            for relative in FILES[name]:
                actual=(repo/relative).read_bytes()
                require(actual==git("show",pin+":"+relative),"SOURCE_BYTES_MISMATCH")
                hashes[relative]=hashlib.sha256(actual).hexdigest()
            manifest[name]={"commit":pin,"files":hashes}
        require(self.binary.is_file(),"LEAN_UNAVAILABLE")
        manifest["zverdict_exe_sha256"]=hashlib.sha256(self.binary.read_bytes()).hexdigest()
        return manifest


def adapter_hashes():
    root=Path(__file__).resolve().parent.parent
    return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/"commerce_adapter").glob("*.py")}


def bridge_hashes():
    return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(__file__).resolve().parent.glob("*.py")}
